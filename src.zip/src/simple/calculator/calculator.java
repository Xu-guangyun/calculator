package simple.calculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Constant.Class.Const;
import java.math.BigDecimal;

public class calculator extends JFrame implements ActionListener{
	 // 北部面板、输入文本框、清除按钮
    private JPanel jp_north = new JPanel();
    private JTextField input_text = new JTextField();
    private JButton c_Btn = new JButton("C");
	
    private JPanel jp_center=new JPanel();
    public calculator() throws HeadlessException {
        this.init();
        this.addNorthComponent();
        this.addCenterButton();
    }
	public void init(){
        this.setTitle(Const.TITLE);
        this.setSize(Const.FRAME_W, Const.FRAME_H);
        this.setLayout(new BorderLayout());
        this.setResizable(false);
        this.setLocation(Const.FRAME_X, Const.FRAME_Y);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
	

	public void addNorthComponent() {
		this.input_text.setPreferredSize(new Dimension(230, 30));
        jp_north.add(input_text);
        this.c_Btn.setForeground(Color.RED);
        jp_north.add(c_Btn);
        c_Btn.addActionListener(this); // 为C按钮添加监听器

        this.add(jp_north,BorderLayout.NORTH);
		
	}
	
	public void addCenterButton() {
        String btn_text="789/456*123-0.=+";
		this.jp_center.setLayout(new GridLayout(4,4));
        for (int i = 0; i < 16; i++) {
        	String temp=btn_text.substring(i,i+1);
            JButton btn = new JButton();
            btn.setText(temp);
            if(temp.equals("+")||temp.equals("-")||temp.equals("*")||temp.equals("/")||temp.equals(".")||temp.equals("="))
                btn.setFont(new Font("粗体",Font.BOLD,16));
            btn.addActionListener(this);
            jp_center.add(btn);
            
        }
        this.add(jp_center, BorderLayout.CENTER);
    }
	
    public static void main(String[] args) {
        calculator carculator = new calculator();
        carculator.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String clickStr = e.getActionCommand();

        if (clickStr.equals("=")) {
            String expression = input_text.getText();
            try {
                BigDecimal result = PolynomialCalculator.evaluate(expression);
                input_text.setText(result.toPlainString()); // 直接显示结果，去除末尾的0
            } catch (Exception ex) {
                input_text.setText("Error");
            }
        } else if (clickStr.equals("C")) {
        	input_text.setText(""); // 直接清空输入框内容
        } else {
            input_text.setText(input_text.getText() + clickStr);
        }
        input_text.setHorizontalAlignment(JTextField.RIGHT);
    }

}
