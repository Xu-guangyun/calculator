package simple.calculator;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Stack;

public class PolynomialCalculator {

    public static BigDecimal evaluate(String expression) {
        // 使用栈来计算简单的算数运算表达式
        Stack<BigDecimal> values = new Stack<>();
        Stack<Character> operators = new Stack<>();
        char[] tokens = expression.toCharArray();
        
        for (int i = 0; i < tokens.length; i++) {
            char token = tokens[i];

            // 跳过空格
            if (token == ' ') {
                continue;
            }

            // 如果是数字，读取整个数字
            if (Character.isDigit(token) || token == '.') {
                StringBuilder sb = new StringBuilder();
                while (i < tokens.length && (Character.isDigit(tokens[i]) || tokens[i] == '.')) {
                    sb.append(tokens[i]);
                    i++;
                }
                i--; // 回退一个位置，因为for循环会再增加
                values.push(new BigDecimal(sb.toString()));
            } 

            // 如果是左括号
            else if (token == '(') {
                operators.push(token);
            } 

            // 如果是右括号，计算直到左括号
            else if (token == ')') {
                while (operators.peek() != '(') {
                    values.push(applyOperator(operators.pop(), values.pop(), values.pop()));
                }
                operators.pop(); // 弹出 '('
            } 

            // 如果是运算符
            else if (token == '+' || token == '-' || token == '*' || token == '/') {
                while (!operators.isEmpty() && hasPrecedence(token, operators.peek())) {
                    values.push(applyOperator(operators.pop(), values.pop(), values.pop()));
                }
                operators.push(token);
            }
        }

        // 处理剩余的运算符
        while (!operators.isEmpty()) {
            values.push(applyOperator(operators.pop(), values.pop(), values.pop()));
        }

        return values.pop().setScale(5, RoundingMode.HALF_UP).stripTrailingZeros(); // 保留五位小数，去掉尾随零
    }

    // 应用运算符
    private static BigDecimal applyOperator(char operator, BigDecimal b, BigDecimal a) {
        switch (operator) {
            case '+':
                return a.add(b);
            case '-':
                return a.subtract(b);
            case '*':
                return a.multiply(b);
            case '/':
                if (b.compareTo(BigDecimal.ZERO) == 0) throw new ArithmeticException("Cannot divide by zero");
                return a.divide(b, 10, RoundingMode.HALF_UP);  // 限制除法运算精度
        }
        return BigDecimal.ZERO;
    }

    // 判断当前运算符是否有更高的优先级
    private static boolean hasPrecedence(char op1, char op2) {
        if (op2 == '(' || op2 == ')') {
            return false;
        }
        if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-')) {
            return false;
        }
        return true;
    }
}


